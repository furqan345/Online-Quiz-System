
</main>

<footer class="main-footer">
    <p>&copy; <?php echo date("Y"); ?> Online Quiz and Result Management System - FYP Project</p>
</footer>

</body>
</html>
